import Foundation
import UIKit


class Functions {
    static var shared = Functions()
    func scientificNotation(for number: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .scientific
        if abs(number) > 10000 {
            formatter.positiveFormat = "0.###E+0"
            formatter.negativeFormat = "0.###E-0"
            return formatter.string(from: NSNumber(value: number)) ?? "\(number)"
        } else {
            formatter.minimumFractionDigits = 1
            formatter.maximumFractionDigits = 1
            return formatter.string(from: NSNumber(value: number)) ?? "\(number)"
        }
    }
}

extension UIColor {
    static var appMainColor = UIColor.systemBackground
}

extension UIButton {
    func roundAndShadow() {
        layer.cornerRadius = 10
        layer.borderWidth = 5
        layer.borderColor = UIColor.systemBackground.cgColor
        layer.shadowColor = UIColor.white.cgColor
        layer.shadowOpacity = 0.8
        layer.shadowOffset = CGSize(width: 0, height: 5)
        layer.shadowRadius = 8
    }
}

extension UITextField {
    func roundAndShadow() {
        layer.cornerRadius = 5
        layer.borderWidth = 5
        layer.borderColor = UIColor.systemBackground.cgColor
        layer.shadowColor = UIColor.white.cgColor
        layer.shadowOpacity = 0.8
        layer.shadowOffset = CGSize(width: 0, height: 5)
        layer.shadowRadius = 8
    }
}

extension UIView {
    func roundAndShadowView() {
        layer.cornerRadius = 8
        layer.borderWidth = 8
        layer.borderColor = UIColor.systemBackground.cgColor
        layer.shadowColor = UIColor.white.cgColor
        layer.shadowOpacity = 0.8
        layer.shadowOffset = CGSize(width: 0, height: 5)
        layer.shadowRadius = 8
    }
}
