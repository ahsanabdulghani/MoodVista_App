import UIKit

class MoodEntryViewController: UIViewController {
    
    @IBOutlet weak var happyButton: UIButton!
    @IBOutlet weak var sadButton: UIButton!
    @IBOutlet weak var excitedButton: UIButton!
    @IBOutlet weak var calmButton: UIButton!
    @IBOutlet weak var angryButton: UIButton!
    @IBOutlet weak var tiredButton: UIButton!
    
    @IBOutlet weak var optionalTextField: UITextView!
    @IBOutlet weak var happyLabel: UILabel!
    @IBOutlet weak var sadLabel: UILabel!
    @IBOutlet weak var excitedLabel: UILabel!
    @IBOutlet weak var calmLabel: UILabel!
    @IBOutlet weak var angryLabel: UILabel!
    @IBOutlet weak var tiredLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Assuming textField is your UITextField instance
        optionalTextField.textContainer.maximumNumberOfLines = 0
        optionalTextField.textContainer.lineBreakMode = .byWordWrapping
       // optionalTextField.isScrollEnabled = true // You might want to enable scrolling if needed

        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
    }
    
    @IBAction func emojiButtonTapped(_ sender: UIButton) {
        
        guard let selectedEmoji: UIImage = {
            switch sender {
            case happyButton:
                print("Selected Emoji: Happy")
                return UIImage(named: "Happy")
            case sadButton:
                print("Selected Emoji: Sad")
                return UIImage(named: "Sad")
            case excitedButton:
                print("Selected Emoji: Excited")
                return UIImage(named: "Excited")
            case calmButton:
                print("Selected Emoji: Calm")
                return UIImage(named: "Calm")
            case angryButton:
                print("Selected Emoji: Angry")
                return UIImage(named: "Angry")
            case tiredButton:
                print("Selected Emoji: Tired")
                return UIImage(named: "Tired")
            default:
                return nil
            }
        }() else {
            print("Error: Unable to find selected emoji image")
            return
        }
        
        let selectedLabel: String = {
            switch sender {
            case happyButton: return "Happy"
            case sadButton: return "Sad"
            case excitedButton: return "Excited"
            case calmButton: return "Calm"
            case angryButton: return "Angry"
            case tiredButton: return "Tired"
            default: return ""
            }
        }()
        
        let defaults = UserDefaults.standard
        defaults.set(selectedEmoji.pngData(), forKey: "selectedEmoji")
        defaults.set(selectedLabel, forKey: "selectedLabel")
        defaults.set(Date(), forKey: "currentDate")
        defaults.synchronize()
        
        updateMoodHistoryUI(selectedEmoji: selectedEmoji, selectedLabel: selectedLabel)
    }
    
    @IBAction func saveButton(_ sender: Any) {
        let optionalText = optionalTextField.text ?? ""
        
        let defaults = UserDefaults.standard
        defaults.set(optionalText, forKey: "optionalText")
        defaults.synchronize()
        
        let alertController = UIAlertController(title: "Alert", message: "Successfully Saved!", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (_) in
            print("OK button tapped")
        }
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
        optionalTextField.text = ""
    }
    
    func updateMoodHistoryUI(selectedEmoji: UIImage, selectedLabel: String) {
        guard let tabBarController = self.tabBarController,
              let moodHistoryViewController = tabBarController.viewControllers?.first(where: { $0 is MoodHistoryViewController }) as? MoodHistoryViewController else {
                  print("Error: MoodHistoryViewController not found in tab bar controller")
                  return
              }
        
        moodHistoryViewController.selectedEmoji = selectedEmoji
        moodHistoryViewController.selectedLabel = selectedLabel
        moodHistoryViewController.currentDate = Date()
        moodHistoryViewController.optionalText = UserDefaults.standard.string(forKey: "optionalText")
        moodHistoryViewController.updateSelectedMoodUI()
    }
}
