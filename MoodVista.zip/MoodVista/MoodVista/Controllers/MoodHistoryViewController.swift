import UIKit

class MoodHistoryViewController: UIViewController {
    @IBOutlet weak var selectedEmojiImageView: UIImageView!
    @IBOutlet weak var selectedMoodLabel: UILabel!
    @IBOutlet weak var currentDateLabel: UILabel!
    @IBOutlet weak var optionalTextLabel: UILabel!
    
    var selectedEmoji: UIImage?
    var selectedLabel: String?
    var currentDate: Date?
    var optionalText: String?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadMoodData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateSelectedMoodUI()
    }
    
    func loadMoodData() {
        let defaults = UserDefaults.standard
        if let storedEmojiData = defaults.object(forKey: "selectedEmoji") as? Data,
           let storedEmoji = UIImage(data: storedEmojiData),
           let storedLabel = defaults.string(forKey: "selectedLabel"),
           let storedDate = defaults.object(forKey: "currentDate") as? Date,
           let storedOptionalText = defaults.string(forKey: "optionalText") {
            
            selectedEmoji = storedEmoji
            selectedLabel = storedLabel
            currentDate = storedDate
            optionalText = storedOptionalText
            
            updateSelectedMoodUI()
        }
    }
    
    func updateSelectedMoodUI() {
        guard let selectedEmojiImageView = selectedEmojiImageView else {
            print("Error: selectedEmojiImageView is nil")
            return
        }
        
        selectedEmojiImageView.image = selectedEmoji
        selectedMoodLabel.text = selectedLabel
        optionalTextLabel.text = optionalText
        if let currentDate = currentDate {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM dd, yyyy"
            currentDateLabel.text = dateFormatter.string(from: currentDate)
        }
    }
}
