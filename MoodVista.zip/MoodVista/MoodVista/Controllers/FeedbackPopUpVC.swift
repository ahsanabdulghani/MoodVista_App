import UIKit

class FeedbackPopUpVC: UIViewController {
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var feedbackTF: UITextField!
    @IBOutlet weak var feedbackBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        backView.roundAndShadowView()
        feedbackTF.roundAndShadow()
        feedbackBtn.roundAndShadow()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
        
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    @IBAction func feedbackPressed(_ sender: Any) {
        if feedbackTF.text == ""{
            showAlert(message: "Please enter feedback")
        }else{
            showAlert(message: "Feedback sent successfully")
            feedbackTF.text = ""
            
        }
    }
    @IBAction func dismissPressed(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
}


extension UIViewController{
    func showAlert(message:String){
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
        alertController.addAction(okayAction)
        self.present(alertController, animated: true, completion: nil)
    }
}
