import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imgViewLogo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgViewLogo.layer.cornerRadius = imgViewLogo.frame.size.width / 3
        imgViewLogo.clipsToBounds = true
    }
}
