import UIKit

class SplashScreenViewController: UIViewController {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var imgViewLogo: UIImageView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        activityIndicator.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.activityIndicator.stopAnimating()
            self.performSegue(withIdentifier: "ViewController", sender: self)
            
        }
        imgViewLogo.layer.cornerRadius = imgViewLogo.frame.size.width / 3
        imgViewLogo.clipsToBounds = true
    }
    
}
