import UIKit
import StoreKit

class MoreOptionVC: UIViewController {
    @IBOutlet var btns: [UIButton]!
    
    @IBOutlet weak var feebackBtn: UIButton!
    @IBOutlet weak var privacyBtn: UIButton!
    @IBOutlet weak var termconditionBtn: UIButton!
    @IBOutlet weak var shareBtn: UIButton!
    @IBOutlet weak var ratingBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for btn in btns{
            btn.roundAndShadow()
        }
        feebackBtn.layer.shadowOpacity = 0.3
        feebackBtn.layer.shadowRadius = 2.0
        feebackBtn.layer.shadowColor = UIColor.yellow.cgColor
        feebackBtn.layer.cornerRadius = 5
        
        privacyBtn.layer.shadowOpacity = 0.3
        privacyBtn.layer.shadowRadius = 2.0
        privacyBtn.layer.shadowColor = UIColor.yellow.cgColor
        privacyBtn.layer.cornerRadius = 5
        
        termconditionBtn.layer.shadowOpacity = 0.3
        termconditionBtn.layer.shadowRadius = 2.0
        termconditionBtn.layer.shadowColor = UIColor.yellow.cgColor
        termconditionBtn.layer.cornerRadius = 5
        
        shareBtn.layer.shadowOpacity = 0.3
        shareBtn.layer.shadowRadius = 2.0
        shareBtn.layer.shadowColor = UIColor.yellow.cgColor
        shareBtn.layer.cornerRadius = 5
        
        ratingBtn.layer.shadowOpacity = 0.3
        ratingBtn.layer.shadowRadius = 2.0
        ratingBtn.layer.shadowColor = UIColor.yellow.cgColor
        ratingBtn.layer.cornerRadius = 5
        
    }
    @IBAction func feedBackPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FeedbackPopUpVC") as! FeedbackPopUpVC
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    @IBAction func privacyPolicyPressed(_ sender: Any) {
        presentPrivacyPolicy()
    }
    @IBAction func termsPressed(_ sender: Any) {
        presentTermsAndConditions()
    }
    @IBAction func sharePressed(_ sender: Any) {
        if let link = NSURL(string: "https://www.apple.com") {
            let objectsToShare = [link] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    @IBAction func giveRatingPressed(_ sender: Any) {
        if #available(iOS 10.3, *) {
            SKStoreReviewController.requestReview()
        } else {
            
            
        }
    }
    
    
    private func presentPrivacyPolicy() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        vc.newTitle = "Privacy Policy"
        vc.newDescription = """
            Personal Information: We do not collect any personally identifiable information (PII) that can directly identify you, such as your name, address, or contact details.
            
            Non-Personal Information: We may collect non-personal information that does not directly identify you. This may include information such as device information, operating system, and anonymous usage data.
            
            How We Use Your Information
            
            We may use the collected information for the following purposes:
            
            App Improvement: To improve and enhance the functionality and features of the App.
            
            Usage Analytics: To analyze how the App is used, troubleshoot issues, and provide user support.
            
            Third-Party Services
            
            The App may include links to third-party websites or services. We are not responsible for the privacy practices of these third-party services. Please review their privacy policies when using their services.
            """
        present(vc, animated: true)
    }
    
    private func presentTermsAndConditions() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        vc.newTitle = "Terms & Conditions"
        vc.newDescription = """
            MoodVista" is provided for personal use and reference purposes only.
            While we strive for accuracy, we cannot guarantee the precision of the conversions in all cases. Users are encouraged to double-check results for critical applications.
            The app is not intended as a replacement for professional advice or critical calculations.
            Users must not engage in any activity that may damage, disrupt, or compromise the app's functionality.
            This includes attempts to hack, reverse engineer, or distribute harmful code.
            Users should respect the rights and privacy of others when using the app
            We welcome user feedback to improve our app. If you encounter issues or have suggestions for enhancements, please contact us through the provided support channels.
            We will make reasonable efforts to address user concerns and provide support
            """
        present(vc, animated: true)
    }
}
